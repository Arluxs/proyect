/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import com.mysql.cj.xdevapi.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 *
 * @author hilde
 */
public class conecxionBD {

    String bd = "clase14";
    String url = "jdbc:mysql://localhost:3306/";
    String user = "Arluxs";
    String pass = "1234";
    String driver = "com.mysql.cj.jdbc.Driver"; //VersiÃ³n 8 (version 5 va sin cj)
    Connection cx;

    public conecxionBD() {
    }

    public Connection conectar() {
        try {
            Class.forName(driver);
            cx = DriverManager.getConnection(url + bd, user, pass);
            
            System.out.println("CONEXIÃ“N CON LA BD " + bd);
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("ERROR EN LA CONEXION A LA BD " + bd);
        }
        return cx;
    }

    public void desconectar() {
        try {
            cx.close();
        } catch (SQLException ex) {
            System.out.println("No se pudo desconectar ");
        }
    }

    public static void main(String[] args) {
        conecxionBD conect = new conecxionBD();
        conect.conectar();
    }

    public boolean ejecutasql(String cadenasql) {
        try {
            PreparedStatement pstm = cx.prepareStatement(cadenasql);
            pstm.execute();
            return true;

        } catch (SQLException e) {
            System.err.println("Error: " + e);
            return false;
        }

    }

    public ResultSet registros(String cadenasql) {
        try {
            PreparedStatement pstm = cx.prepareStatement(cadenasql);
            ResultSet respuesta = pstm.executeQuery(cadenasql);
            return respuesta;
        } catch (Exception e) {
            System.err.println("Error: " + e);
            return null;

        }

    }
    
   
  

}
