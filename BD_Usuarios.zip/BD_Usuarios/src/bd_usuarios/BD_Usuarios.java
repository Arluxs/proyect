/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bd_usuarios;

import vista.formusuarios;
import vista.frameprincipal;

/**
 *
 * @author hilde
 */
public class BD_Usuarios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        frameprincipal frame1 = new frameprincipal();
        frame1.setVisible(true);

    }


}
