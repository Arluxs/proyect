package bd_usuarios;

import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;
import modelo.conecxionBD;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import vista.*;

public class claseusuario {

    private int id;
    private String rut, nombre, apellido, contrasena;
    String datos[] = new String[5];
    ArrayList arreglousu = new ArrayList<>();

    public claseusuario() {
    }

    public claseusuario(int id, String rut, String nombre, String apellido, String contrasena) {
        this.id = id;
        this.rut = rut;
        this.nombre = nombre;
        this.apellido = apellido;
        this.contrasena = contrasena;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public boolean agregarusuario() {
        conecxionBD conect = new conecxionBD();
        conect.conectar();
        boolean resultado = true;

        try {
            resultado = conect.ejecutasql("INSERT INTO USUARIO VALUES (NULL,'" + this.rut + "','" + this.nombre + "','" + this.apellido + "','" + this.contrasena + "')");

        } catch (Exception e) {
            System.err.println("Erroe en la busqueda: " + e);

        }
        conect.desconectar();
        return resultado;
    }

    public boolean Validacion_Concreta() {

        Boolean lDevuelve = false;
        int Ult = this.rut.length(); // |1 |8 |2 |1 |6 |5 |7 |1 |- |9 | = 10? = 9
        int Largo = this.rut.length() - 3;
        int Constante = 2;
        int Suma = 0;
        int Digito = 0;

        for (int i = Largo; i >= 0; i--) {

            Suma = Suma + Integer.parseInt(this.rut.substring(i, i + 1)) * Constante;
            Constante = Constante + 1;
            if (Constante == 8) {
                Constante = 2;
            }
        }
        String Ultimo = this.rut.substring(Ult - 1).toUpperCase();
        Digito = 11 - (Suma % 11);
        if (Digito == 10 && Ultimo.equals("K")) {
            lDevuelve = true;
        } else {
            if (Digito == 11 && Ultimo.equals("0")) {
                lDevuelve = true;
            } else {

                if (Digito == Integer.parseInt(Ultimo)) {

                    lDevuelve = true;

                }

            }

        }
        return lDevuelve;

    }

    public boolean eliminarusuario() {
        conecxionBD conect = new conecxionBD();
        conect.conectar();
        boolean resultado = true;

        try {
            conect.ejecutasql("DELETE FROM usuario WHERE rut = '" + this.rut + "'");
            System.out.println("DELETE FROM usuario WHERE rut = " + this.rut);
        } catch (Exception e) {
            System.err.println("Erroe en la busqueda: " + e);

        }
        conect.desconectar();
        return resultado;
    }

    public boolean existe() {
        conecxionBD conect = new conecxionBD();
        conect.conectar();
        String sql = "SELECT * FROM USUARIO WHERE RUT = '" + this.rut + "'";
        System.out.println(sql);

        try {
            boolean pst = conect.ejecutasql(sql);
            ResultSet rs = conect.registros(sql);
            System.out.println(this.rut);

            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);

            }
            System.out.println(datos[1]);
            if (datos[1].equals(this.rut)) {
                JOptionPane.showMessageDialog(null, "RUT YA SE ENCUENTRA EN NUESTRA BASE DE DATOS");
                return true;

            } else {
                return false;

            }
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "ERROR2, \n");
            return false;

        }

    }

    public ArrayList mostrardatos() {
        conecxionBD conect = new conecxionBD();
        conect.conectar();
        System.out.println("holap");
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("RUT");
        modelo.addColumn("NOMBRE");
        modelo.addColumn("APELLIDO");
        String sql = "SELECT * FROM USUARIO WHERE RUT = '" + this.rut + "'";
        System.out.println(sql);

        try {
            boolean pst = conect.ejecutasql(sql);
            ResultSet rs = conect.registros(sql);
            System.out.println(rs);

            System.out.println(datos[0]);
            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
                modelo.addRow(datos);
                System.out.println(modelo);
                arreglousu.add(datos[0]);
                arreglousu.add(datos[1]);
                arreglousu.add(datos[2]);
                arreglousu.add(datos[3]);
                arreglousu.add(datos[4]);
                return arreglousu;

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "USUARIO NO EXISTE");
        }
        arreglousu.add(datos[0]);

        return arreglousu;

    }

    public boolean modificarusuario() {
        conecxionBD conect = new conecxionBD();
        conect.conectar();
        boolean resultado = true;

        try {
            resultado = conect.ejecutasql("UPDATE USUARIO SET NOMBRE = '" + this.nombre + "', APELLIDO = '" + this.apellido + "', contrasena = " + this.contrasena + " WHERE rut = '" + this.rut + "'");

        } catch (Exception e) {
            System.err.println("ERROR USUARIO NO ELIMINADO " + e);

        }
        conect.desconectar();
        return resultado;

    }

    public void tablas(JTable ta) {

        conecxionBD conect = new conecxionBD();
        conect.conectar();
        System.out.println("holap");
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("NOMBRE");
        modelo.addColumn("APELLIDO");
        modelo.addColumn("CONTRASEÑA");

        String sql = "SELECT * FROM USUARIO";
        System.out.println(sql);
        String datos[] = new String[5];

        try {
            boolean pst = conect.ejecutasql(sql);
            ResultSet rs = conect.registros(sql);
            System.out.println(rs);

            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
                modelo.addRow(datos);
                ta.setModel(modelo);
                System.out.println(modelo);
                arreglousu.add(datos[0]);
                arreglousu.add(datos[1]);
                arreglousu.add(datos[2]);
                arreglousu.add(datos[3]);
                arreglousu.add(datos[4]);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "USUARIO NO EXISTE");
        }
    }
}
